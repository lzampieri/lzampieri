<?php get_template_part('parts/header'); ?>

<?php get_template_part('parts/normal_header'); ?>

<?php get_template_part('parts/navigation'); ?>

<?php get_template_part('parts/title', null, array( 'title' => "Pagina non trovata" ) ); ?>

<?php get_template_part('parts/navigation_bottom'); ?>

<?php get_template_part('parts/footer'); ?>
