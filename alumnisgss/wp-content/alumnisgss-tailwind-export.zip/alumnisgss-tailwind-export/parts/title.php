<div class="flex flex-row items-center justify-center w-full pt-32">
    <h2 class="w-5/6 md:w-2/5
        border-y-4 border-details-bg rounded
        text-dark-tx py-4
        text-center
        ">
        <?php echo apply_filters( 'the_title', $args['title'] ); ?>
    </h2>
</div>