<?php get_template_part('parts/header'); ?>

<?php get_template_part('parts/home_header'); ?>

<?php get_template_part('parts/navigation'); ?>

<?php get_template_part('parts/sections_list', null, array( 'sections_ref' => 'homepage' ) ); ?>

<?php get_template_part('parts/navigation_bottom'); ?>

<?php get_template_part('parts/footer'); ?>